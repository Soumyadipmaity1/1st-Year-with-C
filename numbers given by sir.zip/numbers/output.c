#include <stdio.h>
int main()
{
	int i=42;
	printf("%d %d %d",i++,++i,i++);
	return 0;
}
